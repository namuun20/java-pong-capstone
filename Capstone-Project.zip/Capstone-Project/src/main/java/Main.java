public class Main {
  public static void main(String[] args) {
public class PongGame extends JPanel implements KeyListener, ActionListener {

    // Game settings
    private final int WIDTH = 800;
    private final int HEIGHT = 600;
    private final int PADDLE_WIDTH = 20;
    private final int PADDLE_HEIGHT = 100;
    private final int BALL_SIZE = 20;

    // Player and AI paddles
    int playerY = HEIGHT / 2 - PADDLE_HEIGHT / 2;
    int aiY = HEIGHT / 2 - PADDLE_HEIGHT / 2;

    // Ball position and speed
    int ballX = WIDTH / 2 - BALL_SIZE / 2;
    int ballY = HEIGHT / 2 - BALL_SIZE / 2;
    int ballXSpeed = 4;
    int ballYSpeed = 4;

    // Player movement
    boolean upPressed = false, downPressed = false;

    // Score
    int playerScore = 0;
    int aiScore = 0;

    Timer timer;

    public PongGame() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        timer = new Timer(10, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw center line
        g.setColor(Color.GRAY);
        g.drawLine(WIDTH / 2, 0, WIDTH / 2, HEIGHT);

        // Draw paddles
        g.setColor(Color.WHITE);
        g.fillRect(30, playerY, PADDLE_WIDTH, PADDLE_HEIGHT); // Player
        g.fillRect(WIDTH - 50, aiY, PADDLE_WIDTH, PADDLE_HEIGHT); // AI

        // Draw ball
        g.fillOval(ballX, ballY, BALL_SIZE, BALL_SIZE);

        // Draw scores
        g.setFont(new Font("Consolas", Font.BOLD, 36));
        g.drawString(String.valueOf(playerScore), WIDTH / 2 - 60, 50);
        g.drawString(String.valueOf(aiScore), WIDTH / 2 + 30, 50);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Move player
        if (upPressed && playerY > 0) playerY -= 6;
        if (downPressed && playerY < HEIGHT - PADDLE_HEIGHT) playerY += 6;

        // Move AI (simple tracking)
        if (ballY < aiY + PADDLE_HEIGHT / 2) aiY -= 4;
        if (ballY > aiY + PADDLE_HEIGHT / 2) aiY += 4;

        // Move ball
        ballX += ballXSpeed;
        ballY += ballYSpeed;

        // Bounce off top and bottom
        if (ballY <= 0 || ballY >= HEIGHT - BALL_SIZE) ballYSpeed *= -1;

        // Bounce off player paddle
        if (ballX <= 50 && ballY + BALL_SIZE >= playerY && ballY <= playerY + PADDLE_HEIGHT) {
            ballXSpeed *= -1;
        }

        // Bounce off AI paddle
        if (ballX >= WIDTH - 70 && ballY + BALL_SIZE >= aiY && ballY <= aiY + PADDLE_HEIGHT) {
            ballXSpeed *= -1;
        }

        // Score
        if (ballX < 0) {
            aiScore++;
            resetBall();
        }
        if (ballX > WIDTH) {
            playerScore++;
            resetBall();
        }

        repaint();
    }

    private void resetBall() {
        ballX = WIDTH / 2 - BALL_SIZE / 2;
        ballY = HEIGHT / 2 - BALL_SIZE / 2;
        ballXSpeed *= -1;
    }

    // Key controls
    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP) upPressed = true;
        if (e.getKeyCode() == KeyEvent.VK_DOWN) downPressed = true;
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP) upPressed = false;
        if (e.getKeyCode() == KeyEvent.VK_DOWN) downPressed = false;
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    // Main method to launch the game
    public static void main(String[] args) {
        JFrame frame = new JFrame("Pong Game - Capstone Project");
        PongGame gamePanel = new PongGame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(gamePanel);
        frame.pack();
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}